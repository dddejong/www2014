<div class="gallery clearfix">
	<h3><?php print $title;?>  <?php if ($edit) { print '<span class="edit-small">('.$edit.')</span>'; } ?></h3>

	<div class="gallery-thumb">
 		<?php print $field_image_fid; ?>
 	</div>
	<div class="gallery-desc">
  		<?php print $field_teaser_value; ?>
  	</div>
  </div>

