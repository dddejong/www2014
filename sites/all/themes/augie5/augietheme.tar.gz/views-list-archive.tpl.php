<?php print $title?> <?php if ($edit) { print '('.$edit.')'; } ?>


