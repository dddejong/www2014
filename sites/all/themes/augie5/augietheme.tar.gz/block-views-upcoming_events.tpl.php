<div class="block"> <h3><?php print $block->subject ?></h3>
<?php


print $block->content ?>
</div>
