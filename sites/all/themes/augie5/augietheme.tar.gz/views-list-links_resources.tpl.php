<?php dprint_r($node); 

echo $node->node_data_field_link_field_link_url['#value'];
return $output;

?>