<div id="block-<?php print $block->module .'-'. $block->delta; ?>" class="clear-block block block-<?php print $block->module ?>">

<?php
//print_r($path_root_array);
if ($path_root_array[2] 
&& ($path_root_array[1] == 'majors-minors-and-pre-professional-programs' || $path_root_array[1] == 'college-offices-and-affiliates')) {
	if ($block->subject && 
	($block->subject != "Majors, Minors and Pre-Professional Programs" ||
	$block->subject != "College Offices and Affiliates")) { ?>
  		<h2><?php print $block->subject ?></h2>
	<?php }
}


?>

  <div class="content"><?php print $block->content ?></div>
</div>
