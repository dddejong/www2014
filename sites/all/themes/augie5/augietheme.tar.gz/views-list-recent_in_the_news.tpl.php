<?php print $field_link_url?> <?php if ($edit) { print '('.$edit.')'; } ?>
<div>
<?php if ($field_source_value) {
	print '('. $field_source_value . ')';
} ?>
</div>


 
 



