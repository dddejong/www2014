<div class="entry">


<?php
//print_r($path_root_array);

if ($block->subject) { ?>
 <h3><?php print $block->subject; ?></h3>
 <h3 class="title">LOG IN TO:</h3>
<?php }
	print $block->content;
?>
</div>
