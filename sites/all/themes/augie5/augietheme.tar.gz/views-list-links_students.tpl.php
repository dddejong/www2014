 
<?php dprint_r($node); ?>

  


 
 



