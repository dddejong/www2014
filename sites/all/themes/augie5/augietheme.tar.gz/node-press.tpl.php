xxx<?php
  print $node->content['body']['#value'];

  ?>


