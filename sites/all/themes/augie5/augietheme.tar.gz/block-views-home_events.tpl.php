
 <h2 class="title"><?php print $block->subject ?></h2>
<?php


print $block->content ?>

