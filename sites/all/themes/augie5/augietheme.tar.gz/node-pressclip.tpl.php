<?php
  print $node->field_link[0]['view'];

  ?>


